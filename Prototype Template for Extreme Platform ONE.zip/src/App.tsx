import ExtremePlatformTemplate from './components/ExtremePlatformTemplate';

export default function App() {
  return <ExtremePlatformTemplate />;
}
